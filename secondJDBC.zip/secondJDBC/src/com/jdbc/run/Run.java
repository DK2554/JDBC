package com.jdbc.run;

import com.jdbc.controller.MemberController;

public class Run {

	public static void main(String[] args) {
		//controller를 호출함
		new MemberController().mainMenu();

	}

}
